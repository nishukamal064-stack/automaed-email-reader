# Technical Report: Automated Email Reminder and Notification System

## 1. Project overview

The system helps students and professionals track assignments, meetings, deadlines, and other scheduled activities. A user creates a task in the website with a title, notes, recipient email, reminder time, and deadline. The app stores the task in SQLite and checks for due reminders in the background. When Gmail delivery succeeds, the app records the delivery and displays it in the activity log.

## 2. Objectives addressed

- Provide a task management interface that runs in a web browser.
- Store reminder information persistently in SQLite.
- Parse and compare date and time values.
- Send email notifications through Python `smtplib` using Gmail SMTP with STARTTLS.
- Reject malformed email addresses and report delivery errors.
- Record task, scheduler, and email events in an activity log.
- Include automated test cases for validation, persistence, and scheduled delivery.

## 3. Architecture

The application uses Python's standard library for the local HTTP server and browser launch. The HTML, CSS, and JavaScript interface calls the local JSON API. A background scheduler shares the database and mail sender with the server.

```text
Browser interface (index.html)
          │ local JSON requests
          ▼
Python HTTP server (app.py)
       ┌──┴──────────────┐
       ▼                 ▼
SQLite database     Background scheduler
(database.py)       (scheduler.py)
                           │
                           ▼
                 Gmail SMTP STARTTLS
                   (email_sender.py)
                           │
                           ▼
              Activity log (logger_config.py)
```

The server binds to `127.0.0.1`, so the website is available from the same computer. No hosting account or third-party JavaScript runtime is required.

## 4. Data model

The `tasks` table contains:

| Field | Purpose |
| --- | --- |
| `id` | Unique task identifier |
| `title`, `description` | Task name and optional notes |
| `recipient_email` | Address that receives the reminder |
| `reminder_time`, `deadline` | Scheduled notification time and due time |
| `status` | `Pending` or `Completed` |
| `reminder_sent` | Prevents repeat delivery after success |
| `created_at`, `sent_at` | Record creation and confirmed delivery times |

Database calls use parameterized SQL and a thread lock. Separate connections are opened for database operations so the web server and scheduler can safely share the SQLite file.

## 5. Reminder and email flow

1. The browser submits a task to `POST /api/tasks`.
2. The server checks the title, email format, date/time values, and reminder-before-deadline rule.
3. The database stores the task with `Pending` status and `reminder_sent = 0`.
4. Every 30 seconds, the scheduler reads pending tasks whose reminder time has arrived.
5. The sender builds a plain-text and HTML email and connects to Gmail SMTP over STARTTLS.
6. On confirmed delivery, the database sets `reminder_sent = 1` and records `sent_at`. On failure, the task remains pending for retry and the error is logged.

Credentials come from environment variables or the local `.env` file. The app does not store credentials in SQLite or in browser code.

## 6. Validation and error handling

The server rejects blank or overlong task titles, invalid recipient addresses, invalid date/time strings, and reminder times later than their deadlines. Email address validation rejects newline characters to prevent email header injection. SMTP authentication, connection, timeout, and recipient failures return readable messages and create log entries. A failed send does not set the sent flag.

## 7. Website features

The dashboard shows task totals and email delivery status. Users can add, search, complete, and delete tasks, review recent activity, view a weekly schedule, and send a test message. Email setup instructions are available in the website. The layout adapts to smaller screens.

## 8. Test strategy

`tests/test_reminders.py` covers supported and invalid date/time input, email validation, SQLite create/complete/delete and summary counts, successful scheduled delivery, duplicate prevention, and retry behavior after a simulated delivery failure. The scheduler tests use a fake sender, so they do not transmit email. See `TEST_CASES.md` for the test-case list.

## 9. Setup and operation

Python 3.10 or newer is required. No additional packages are required. Start the website with `Run Website.bat` on Windows or `python app.py` in a terminal. Gmail delivery requires a Google App Password with 2-Step Verification enabled. The local service must remain running for scheduled reminders to be checked.

## 10. Limitations and future improvements

- The local app must remain open for the scheduler to run.
- Gmail SMTP requires internet access and a valid App Password.
- The scheduler uses the computer's local time zone.
- The current app is designed for one local user and does not provide multi-user sign-in or cloud synchronization.

Potential extensions include recurring reminders, editing existing tasks, export/import, timezone selection, and deployment to a secured hosted server.
