"""
logger_config.py
----------------
Configures centralized application logging for the Automated Email Reminder
and Notification System. All task events, scheduler cycles, SMTP deliveries,
and error conditions are written to 'activity.log' with UTF-8 encoding.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("REMINDER_DATA_DIR") or BASE_DIR)
LOG_FILE_PATH = DATA_DIR / "activity.log"
LOGGER_NAME = "EmailReminderSystem"


def setup_logger(name: str = LOGGER_NAME) -> logging.Logger:
    """
    Create and configure the application logger.

    Ensures handlers are attached only once so repeated imports do not
    produce duplicate log entries.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not logger.handlers:
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(module)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        # File handler writes persistently to activity.log
        file_handler = logging.FileHandler(
            LOG_FILE_PATH, mode="a", encoding="utf-8"
        )
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        # Console handler provides real-time feedback during terminal runs
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    return logger


def get_log_file_path() -> Path:
    """Return the absolute path to activity.log."""
    return LOG_FILE_PATH


def read_activity_logs(max_lines: int = 500) -> str:
    """
    Read up to the latest `max_lines` lines from activity.log.

    Returns a user-friendly message if the log file does not yet exist
    or contains no entries.
    """
    if not os.path.exists(LOG_FILE_PATH):
        return "No activity logs recorded yet."

    try:
        with open(LOG_FILE_PATH, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()

        if not lines:
            return "Activity log file is currently empty."

        recent_lines = lines[-max_lines:]
        return "".join(recent_lines)
    except OSError as exc:
        return f"Unable to read activity log file: {exc}"


def clear_activity_logs() -> tuple[bool, str]:
    """
    Truncate activity.log and record a fresh log entry noting the reset.
    """
    try:
        with open(LOG_FILE_PATH, "w", encoding="utf-8") as f:
            f.write("")
        logger = setup_logger()
        logger.info("Activity logs cleared by user.")
        return True, "Activity logs cleared successfully."
    except OSError as exc:
        return False, f"Failed to clear activity logs: {exc}"
