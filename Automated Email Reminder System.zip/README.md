# Automated Email Reminder and Notification System

A local website for creating tasks and sending scheduled email reminders. The interface runs in a browser; Python handles the web server, SQLite storage, Gmail delivery, scheduling, and activity logging.

## Run the website

1. Install Python 3.10 or newer.
2. Double-click **Run Website.bat** on Windows, or run `python app.py` in this folder.
3. The dashboard opens at `http://127.0.0.1:8765`. Keep the command window open while reminders need to be sent.

The app uses only the Python standard library. It does not need Node.js, npm, or pip packages.

## Configure Gmail

Email delivery is optional until credentials are configured.

1. Enable 2-Step Verification for the Gmail account that will send reminders.
2. Create a Google App Password for this app.
3. Copy `.env.example` to a file named `.env` in this folder.
4. Set `REMINDER_EMAIL` to the Gmail address and `REMINDER_EMAIL_APP_PASSWORD` to the 16-character App Password.
5. Restart the app and use **Email setup → Send a test email** in the website.

Keep `.env` private. Do not use your regular Gmail password or commit `.env` to source control.

The scheduler checks pending tasks every 30 seconds. A reminder is marked sent only after SMTP confirms delivery. Failed deliveries stay pending and are retried on a later check.

## Project files

- `app.py` — Python web server and JSON API
- `index.html` — responsive website dashboard
- `database.py` — SQLite schema and task operations
- `email_sender.py` — email validation, message creation, and Gmail SMTP STARTTLS delivery
- `scheduler.py` — background reminder checks
- `logger_config.py` — activity and error logging
- `tests/test_reminders.py` — automated test cases
- `TEST_CASES.md` — test plan and expected results
- `TECHNICAL_REPORT.md` — design, data flow, and implementation notes
- `final_presentation.html` — browser-based project presentation (also at `/presentation`)
- `.env.example` — safe credential template

Runtime data is stored in `reminders.db` and `activity.log` beside the app.

## Run the test cases

From this folder, run:

```powershell
python -m unittest discover -s tests -v
```

Tests use a temporary SQLite database and a fake email sender. They do not send real email.
