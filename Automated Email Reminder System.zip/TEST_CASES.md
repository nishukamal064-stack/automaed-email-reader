# Test Cases

Automated tests live in `tests/test_reminders.py`. They use temporary SQLite databases and a simulated email sender, so they are safe to run without Gmail credentials or network access.

| ID | Test | Expected result |
| --- | --- | --- |
| TC-01 | Parse `YYYY-MM-DD HH:MM` | Returns the matching Python date/time value |
| TC-02 | Parse `YYYY-MM-DD HH:MM:SS` | Returns the matching Python date/time value |
| TC-03 | Parse malformed date/time text | Raises a clear `ValueError` |
| TC-04 | Validate a well-formed email | Returns valid and trims surrounding spaces |
| TC-05 | Validate a malformed or newline-injected email | Rejects the address |
| TC-06 | Create a task in SQLite | Saves the task as Pending with reminder not sent |
| TC-07 | Complete then delete a task | Updates the status, removes the row, and updates counts |
| TC-08 | Process a due task with successful simulated SMTP | Calls the sender and records one successful delivery |
| TC-09 | Process the same task in a later scheduler cycle | Does not send a duplicate email |
| TC-10 | Process a due task with failed simulated SMTP | Leaves the task Pending and eligible for retry |
| TC-11 | Create a reminder after its deadline through the website | Server rejects the request with an explanatory error |
| TC-12 | Start the website without credentials | Dashboard and task storage work; email setup is shown as needed |
| TC-13 | Send test email with Gmail configured | A verification message is sent and the result is logged |

## Run automated tests

```powershell
python -m unittest discover -s tests -v
```

TC-11 through TC-13 are manual website checks. TC-13 needs valid Gmail App Password credentials and internet access. The other automated cases use no external services.
