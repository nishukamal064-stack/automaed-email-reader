"""
email_sender.py
---------------
Handles email validation, professional reminder message formatting,
and Gmail SMTP delivery over STARTTLS using environment variables
(REMINDER_EMAIL and REMINDER_EMAIL_APP_PASSWORD).
"""

from __future__ import annotations

import html
import os
import re
import smtplib
import socket
import ssl
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any

from logger_config import setup_logger

BASE_DIR = Path(__file__).resolve().parent
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_TIMEOUT_SECONDS = 20

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


class MissingCredentialsError(Exception):
    """Raised when REMINDER_EMAIL or REMINDER_EMAIL_APP_PASSWORD is missing."""


class EmailDeliveryError(Exception):
    """Raised when SMTP transmission fails."""


def load_local_env_file() -> None:
    """
    Lightweight .env loader using only the Python standard library.
    Populates os.environ from a local .env file only if the key is not
    already defined in the process environment.
    """
    env_path = BASE_DIR / ".env"
    if not env_path.is_file():
        return

    try:
        with open(env_path, "r", encoding="utf-8") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ and value:
                    os.environ[key] = value
    except OSError:
        # Non-fatal: system environment variables still take precedence
        pass


def validate_email_address(email: str) -> tuple[bool, str]:
    """
    Validate an email address format and guard against header injection.
    Returns (is_valid, cleaned_email_or_error_message).
    """
    cleaned = email.strip()
    if not cleaned:
        return False, "Recipient email address is required."
    if any(ch in cleaned for ch in ("\r", "\n")):
        return False, "Invalid characters detected in email address."
    if len(cleaned) > 254 or not EMAIL_REGEX.match(cleaned):
        return False, "Please enter a valid email address (e.g., user@example.com)."
    return True, cleaned


class EmailSender:
    """Sends task reminders and verification emails via Gmail SMTP STARTTLS."""

    def __init__(
        self,
        smtp_host: str = SMTP_HOST,
        smtp_port: int = SMTP_PORT,
        timeout: int = SMTP_TIMEOUT_SECONDS,
    ) -> None:
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.timeout = timeout
        self.logger = setup_logger()

    def get_credentials(self) -> tuple[str, str]:
        """
        Read Gmail SMTP credentials strictly from environment variables.
        Raises MissingCredentialsError if either variable is unset.
        """
        load_local_env_file()
        sender_email = os.environ.get("REMINDER_EMAIL", "").strip()
        app_password = os.environ.get("REMINDER_EMAIL_APP_PASSWORD", "").strip()

        missing = []
        if not sender_email:
            missing.append("REMINDER_EMAIL")
        if not app_password:
            missing.append("REMINDER_EMAIL_APP_PASSWORD")

        if missing:
            raise MissingCredentialsError(
                "Missing required environment variable(s): "
                + ", ".join(missing)
                + ". Configure them in your OS environment or .env file before sending emails."
            )

        is_valid, result = validate_email_address(sender_email)
        if not is_valid:
            raise MissingCredentialsError(
                f"REMINDER_EMAIL is invalid: {result}"
            )

        return sender_email, app_password

    def has_credentials(self) -> bool:
        """Return True if both SMTP environment variables are populated."""
        try:
            self.get_credentials()
            return True
        except MissingCredentialsError:
            return False

    def _build_reminder_message(
        self, sender_email: str, task: dict[str, Any]
    ) -> EmailMessage:
        """Construct a professional plain-text + HTML reminder EmailMessage."""
        title = str(task.get("title", "Untitled Task")).strip()
        description = str(task.get("description", "")).strip() or "No additional description provided."
        deadline = str(task.get("deadline", "")).strip()
        reminder_time = str(task.get("reminder_time", "")).strip()
        recipient = str(task.get("recipient_email", "")).strip()

        msg = EmailMessage()
        msg["Subject"] = f"Task Reminder: {title} (Due {deadline})"
        msg["From"] = f"Automated Task Reminder <{sender_email}>"
        msg["To"] = recipient

        plain_body = (
            "AUTOMATED EMAIL REMINDER & NOTIFICATION SYSTEM\n"
            "==============================================\n\n"
            f"Hello,\n\n"
            f"This is an automated reminder for your scheduled task:\n\n"
            f"  Task Title   : {title}\n"
            f"  Deadline     : {deadline}\n"
            f"  Reminder Set : {reminder_time}\n"
            f"  Description  : {description}\n\n"
            "Please review and complete this task before the deadline.\n\n"
            "--\n"
            "Sent automatically by Automated Email Reminder and Notification System\n"
        )
        msg.set_content(plain_body)

        safe_title = html.escape(title)
        safe_desc = html.escape(description).replace("\n", "<br>")
        safe_deadline = html.escape(deadline)
        safe_reminder = html.escape(reminder_time)

        html_body = f"""\
<!DOCTYPE html>
<html>
  <body style="margin:0;padding:24px;background-color:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;color:#1e293b;">
    <table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:0 auto;background:#ffffff;border-radius:10px;overflow:hidden;border:1px solid #e2e8f0;">
      <tr>
        <td style="background:#1e3a8a;color:#ffffff;padding:20px 24px;">
          <p style="margin:0;font-size:12px;letter-spacing:0.8px;text-transform:uppercase;opacity:0.85;">Automated Reminder Notification</p>
          <h1 style="margin:6px 0 0;font-size:20px;font-weight:600;">{safe_title}</h1>
        </td>
      </tr>
      <tr>
        <td style="padding:24px;">
          <p style="margin:0 0 16px;font-size:14px;line-height:1.5;color:#334155;">
            Hello, this is a scheduled reminder for your upcoming task deadline.
          </p>
          <table width="100%" cellpadding="10" cellspacing="0" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">
            <tr>
              <td width="140" style="font-weight:600;color:#475569;border-bottom:1px solid #e2e8f0;">Task Title</td>
              <td style="color:#0f172a;border-bottom:1px solid #e2e8f0;">{safe_title}</td>
            </tr>
            <tr>
              <td style="font-weight:600;color:#475569;border-bottom:1px solid #e2e8f0;">Deadline</td>
              <td style="color:#b91c1c;font-weight:600;border-bottom:1px solid #e2e8f0;">{safe_deadline}</td>
            </tr>
            <tr>
              <td style="font-weight:600;color:#475569;border-bottom:1px solid #e2e8f0;">Reminder Time</td>
              <td style="color:#0f172a;border-bottom:1px solid #e2e8f0;">{safe_reminder}</td>
            </tr>
            <tr>
              <td style="font-weight:600;color:#475569;vertical-align:top;">Description</td>
              <td style="color:#334155;line-height:1.5;">{safe_desc}</td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="background:#f8fafc;padding:14px 24px;font-size:12px;color:#64748b;border-top:1px solid #e2e8f0;">
          Automated Email Reminder and Notification System
        </td>
      </tr>
    </table>
  </body>
</html>
"""
        msg.add_alternative(html_body, subtype="html")
        return msg

    def _build_test_message(self, sender_email: str, recipient_email: str) -> EmailMessage:
        """Construct a verification email for testing SMTP configuration."""
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        msg = EmailMessage()
        msg["Subject"] = "Test Email - Automated Email Reminder and Notification System"
        msg["From"] = f"Automated Task Reminder <{sender_email}>"
        msg["To"] = recipient_email
        msg.set_content(
            "Hello,\n\n"
            "This is a test email from the Automated Email Reminder and Notification System.\n"
            "Your Gmail SMTP (STARTTLS) configuration is working properly.\n\n"
            f"Timestamp: {now_str}\n"
            f"Sender   : {sender_email}\n"
            f"Recipient: {recipient_email}\n"
        )
        return msg

    def _send_via_smtp(self, msg: EmailMessage, sender_email: str, app_password: str) -> None:
        """Transmit an EmailMessage through Gmail SMTP with STARTTLS."""
        context = ssl.create_default_context()
        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=self.timeout) as server:
                server.ehlo()
                server.starttls(context=context)
                server.ehlo()
                server.login(sender_email, app_password)
                server.send_message(msg)
        except smtplib.SMTPAuthenticationError as exc:
            raise EmailDeliveryError(
                "Gmail authentication failed. Verify REMINDER_EMAIL and use a valid 16-character Gmail App Password."
            ) from exc
        except smtplib.SMTPRecipientsRefused as exc:
            raise EmailDeliveryError(
                f"Recipient address was rejected by the SMTP server: {msg['To']}"
            ) from exc
        except smtplib.SMTPConnectError as exc:
            raise EmailDeliveryError(
                f"Unable to connect to {self.smtp_host}:{self.smtp_port}. Check your internet connection."
            ) from exc
        except smtplib.SMTPException as exc:
            raise EmailDeliveryError(f"SMTP error occurred: {exc}") from exc
        except (socket.timeout, TimeoutError) as exc:
            raise EmailDeliveryError(
                "Connection to Gmail SMTP server timed out."
            ) from exc
        except OSError as exc:
            raise EmailDeliveryError(
                f"Network error while connecting to SMTP server: {exc}"
            ) from exc

    def send_reminder_email(self, task: dict[str, Any]) -> tuple[bool, str]:
        """
        Send a reminder email for the given task dictionary.
        Returns (success, status_message).
        """
        task_id = task.get("id", "?")
        recipient = str(task.get("recipient_email", "")).strip()
        title = str(task.get("title", "Untitled")).strip()

        is_valid, cleaned_or_err = validate_email_address(recipient)
        if not is_valid:
            msg = f"Task [ID={task_id}] invalid recipient '{recipient}': {cleaned_or_err}"
            self.logger.error(msg)
            return False, msg

        try:
            sender_email, app_password = self.get_credentials()
            email_msg = self._build_reminder_message(sender_email, task)
            self._send_via_smtp(email_msg, sender_email, app_password)
            success_msg = f"Reminder email sent to {cleaned_or_err} for Task [ID={task_id}] '{title}'."
            self.logger.info(success_msg)
            return True, success_msg
        except (MissingCredentialsError, EmailDeliveryError) as exc:
            err_msg = f"Failed to send reminder for Task [ID={task_id}] '{title}': {exc}"
            self.logger.error(err_msg)
            return False, err_msg
        except Exception as exc:
            err_msg = f"Unexpected error sending reminder for Task [ID={task_id}]: {exc}"
            self.logger.exception(err_msg)
            return False, err_msg

    def send_test_email(self, recipient_email: str) -> tuple[bool, str]:
        """
        Send a test verification email to confirm SMTP connectivity.
        Returns (success, status_message).
        """
        is_valid, cleaned_or_err = validate_email_address(recipient_email)
        if not is_valid:
            self.logger.warning("Test email rejected: %s", cleaned_or_err)
            return False, cleaned_or_err

        try:
            sender_email, app_password = self.get_credentials()
            test_msg = self._build_test_message(sender_email, cleaned_or_err)
            self._send_via_smtp(test_msg, sender_email, app_password)
            success_msg = f"Test email successfully delivered to {cleaned_or_err}."
            self.logger.info(success_msg)
            return True, success_msg
        except (MissingCredentialsError, EmailDeliveryError) as exc:
            err_msg = f"Test email failed: {exc}"
            self.logger.error(err_msg)
            return False, err_msg
        except Exception as exc:
            err_msg = f"Unexpected error sending test email: {exc}"
            self.logger.exception(err_msg)
            return False, err_msg
