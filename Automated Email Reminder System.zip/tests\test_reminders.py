"""Automated tests for date parsing, validation, storage, and scheduled delivery."""
from __future__ import annotations

import os
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

TEST_DATA = tempfile.mkdtemp(prefix="email-reminder-tests-")
os.environ["REMINDER_DATA_DIR"] = TEST_DATA

from database import DatabaseManager, parse_datetime_string  # noqa: E402
from email_sender import validate_email_address  # noqa: E402
from scheduler import ReminderScheduler  # noqa: E402


class FakeEmailSender:
    def __init__(self, succeeds: bool = True) -> None:
        self.succeeds = succeeds
        self.sent: list[dict] = []

    def send_reminder_email(self, task: dict) -> tuple[bool, str]:
        self.sent.append(task)
        return self.succeeds, "delivered" if self.succeeds else "SMTP unavailable"


class ReminderSystemTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory(prefix="reminder-db-")
        self.db = DatabaseManager(Path(self.temp_dir.name) / "test.db")

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def add_task(self, reminder: datetime, deadline: datetime | None = None) -> int:
        deadline = deadline or (reminder + timedelta(hours=1))
        return self.db.add_task(
            title="Review assignment",
            description="Unit test task",
            deadline=deadline.strftime("%Y-%m-%d %H:%M"),
            recipient_email="learner@example.com",
            reminder_time=reminder.strftime("%Y-%m-%d %H:%M"),
        )

    def test_datetime_parser_accepts_supported_formats(self) -> None:
        self.assertEqual(parse_datetime_string("2026-11-26 09:30"), datetime(2026, 11, 26, 9, 30))
        self.assertEqual(parse_datetime_string("2026-11-26 09:30:15"), datetime(2026, 11, 26, 9, 30, 15))

    def test_datetime_parser_rejects_invalid_input(self) -> None:
        with self.assertRaises(ValueError):
            parse_datetime_string("not-a-date")

    def test_email_validation_accepts_valid_and_rejects_invalid_addresses(self) -> None:
        self.assertEqual(validate_email_address(" learner@example.com "), (True, "learner@example.com"))
        self.assertFalse(validate_email_address("invalid-address")[0])
        self.assertFalse(validate_email_address("learner@example.com\r\nBcc:attacker@example.com")[0])

    def test_database_create_complete_delete_and_summary(self) -> None:
        due = datetime.now() + timedelta(hours=1)
        task_id = self.add_task(due)
        self.assertEqual(self.db.get_task_by_id(task_id)["status"], "Pending")
        self.assertTrue(self.db.mark_task_completed(task_id))
        self.assertEqual(self.db.get_summary_counts()["completed"], 1)
        self.assertTrue(self.db.delete_task(task_id))
        self.assertIsNone(self.db.get_task_by_id(task_id))

    def test_scheduler_sends_due_reminder_once_after_success(self) -> None:
        self.add_task(datetime.now() - timedelta(minutes=2), datetime.now() + timedelta(hours=1))
        sender = FakeEmailSender(succeeds=True)
        scheduler = ReminderScheduler(self.db, sender)
        self.assertEqual(scheduler.check_due_reminders(), 1)
        self.assertEqual(scheduler.check_due_reminders(), 0)
        self.assertEqual(len(sender.sent), 1)
        self.assertEqual(self.db.get_summary_counts()["sent"], 1)

    def test_scheduler_keeps_failed_delivery_pending_for_retry(self) -> None:
        task_id = self.add_task(datetime.now() - timedelta(minutes=2), datetime.now() + timedelta(hours=1))
        sender = FakeEmailSender(succeeds=False)
        self.assertEqual(ReminderScheduler(self.db, sender).check_due_reminders(), 0)
        saved = self.db.get_task_by_id(task_id)
        self.assertEqual(saved["status"], "Pending")
        self.assertEqual(saved["reminder_sent"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
