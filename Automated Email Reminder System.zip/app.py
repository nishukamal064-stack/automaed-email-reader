from __future__ import annotations

import json
import os
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from database import DATETIME_FORMAT, DatabaseManager, parse_datetime_string
from email_sender import EmailSender, load_local_env_file, validate_email_address
from logger_config import read_activity_logs
from scheduler import ReminderScheduler

ROOT = Path(__file__).parent
load_local_env_file()
db = DatabaseManager()
sender = EmailSender()


class Handler(BaseHTTPRequestHandler):
    def send_json(self, data, status=200):
        raw = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def body(self):
        return json.loads(self.rfile.read(int(self.headers.get('Content-Length', '0'))) or b'{}')

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/tasks':
            return self.send_json({'tasks': db.get_all_tasks(), 'counts': db.get_summary_counts(), 'smtpConfigured': sender.has_credentials()})
        if path == '/api/logs':
            return self.send_json({'logs': read_activity_logs(max_lines=200)})
        if path == '/':
            return self.send_file('index.html')
        if path == '/presentation':
            return self.send_file('final_presentation.html')
        self.send_error(404)

    def send_file(self, filename):
        file_path = ROOT / filename
        if not file_path.is_file():
            self.send_error(404)
            return
        raw = file_path.read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            data = self.body()
        except (ValueError, json.JSONDecodeError):
            return self.send_json({'error': 'Request body must contain valid JSON.'}, 400)
        if not isinstance(data, dict):
            return self.send_json({'error': 'Request body must be a JSON object.'}, 400)
        if path == '/api/tasks':
            title = str(data.get('title') or '').strip(); email = str(data.get('recipient_email') or '').strip()
            if not title: return self.send_json({'error': 'Task title is required.'}, 400)
            if len(title) > 160: return self.send_json({'error': 'Task title must be 160 characters or fewer.'}, 400)
            ok, validated = validate_email_address(email)
            if not ok: return self.send_json({'error': validated}, 400)
            try:
                deadline = parse_datetime_string(str(data.get('deadline') or '')); reminder = parse_datetime_string(str(data.get('reminder_time') or ''))
            except ValueError as exc: return self.send_json({'error': str(exc)}, 400)
            if reminder > deadline: return self.send_json({'error': 'Reminder time cannot be later than the deadline.'}, 400)
            task_id = db.add_task(title=title, description=str(data.get('description') or '').strip(), deadline=deadline.strftime(DATETIME_FORMAT), recipient_email=validated, reminder_time=reminder.strftime(DATETIME_FORMAT))
            return self.send_json({'id': task_id, 'task': db.get_task_by_id(task_id)}, 201)
        if path == '/api/test-email':
            ok, message = sender.send_test_email(str(data.get('recipient_email', '')).strip())
            return self.send_json({'message': message} if ok else {'error': message}, 200 if ok else 400)
        self.send_error(404)

    def do_PATCH(self):
        path = urlparse(self.path).path.split('/')
        if len(path) == 5 and path[1:3] == ['api', 'tasks'] and path[4] == 'complete' and path[3].isdigit():
            updated = db.mark_task_completed(int(path[3]))
            return self.send_json({'updated': bool(updated)}, 200 if updated else 404)
        self.send_error(404)

    def do_DELETE(self):
        path = urlparse(self.path).path.split('/')
        if len(path) == 4 and path[1:3] == ['api', 'tasks'] and path[3].isdigit():
            deleted = db.delete_task(int(path[3])); return self.send_json({'deleted': bool(deleted)}, 200 if deleted else 404)
        self.send_error(404)

    def log_message(self, *_): pass


def scheduler_loop():
    scheduler = ReminderScheduler(db, sender)
    while True:
        try: scheduler.check_due_reminders()
        except Exception as exc: print(f'Reminder check failed: {exc}')
        time.sleep(30)


if __name__ == '__main__':
    threading.Thread(target=scheduler_loop, daemon=True).start()
    port = int(os.environ.get('PORT', '8765'))
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    url = f'http://127.0.0.1:{port}'
    print(f'Email Reminder is ready at {url}. Keep this window open while using the website.')
    webbrowser.open(url)
    server.serve_forever()
