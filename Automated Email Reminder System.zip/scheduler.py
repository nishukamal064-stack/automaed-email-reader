"""
scheduler.py
------------
Background reminder scheduler that polls SQLite every 30 seconds for
pending tasks whose reminder time is due, sends emails via EmailSender,
prevents duplicate deliveries, and updates reminder_sent only upon success.
"""

from __future__ import annotations

import threading
from datetime import datetime
from typing import Any, Callable

from database import DatabaseError, DatabaseManager
from email_sender import EmailSender
from logger_config import setup_logger

DEFAULT_CHECK_INTERVAL_SECONDS = 30


class ReminderScheduler:
    """Daemon thread scheduler that checks and dispatches due reminders periodically."""

    def __init__(
        self,
        db_manager: DatabaseManager,
        email_sender: EmailSender,
        check_interval_seconds: int = DEFAULT_CHECK_INTERVAL_SECONDS,
        on_reminder_processed: Callable[[dict[str, Any], bool, str], None] | None = None,
        on_cycle_completed: Callable[[datetime, int], None] | None = None,
    ) -> None:
        self.db_manager = db_manager
        self.email_sender = email_sender
        self.check_interval_seconds = max(5, int(check_interval_seconds))
        self.on_reminder_processed = on_reminder_processed
        self.on_cycle_completed = on_cycle_completed
        self.logger = setup_logger()

        self._stop_event = threading.Event()
        self._check_lock = threading.Lock()
        self._thread: threading.Thread | None = None

    def is_running(self) -> bool:
        """Return True when the background scheduler thread is active."""
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        """Start the background reminder polling thread."""
        if self.is_running():
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="ReminderSchedulerThread",
            daemon=True,
        )
        self._thread.start()
        self.logger.info(
            "Reminder scheduler started (checking every %d seconds).",
            self.check_interval_seconds,
        )

    def stop(self, timeout: float = 3.0) -> None:
        """Signal the scheduler thread to stop and wait briefly for shutdown."""
        if not self.is_running():
            return

        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=timeout)
        self.logger.info("Reminder scheduler stopped.")

    def check_due_reminders(self) -> int:
        """
        Evaluate all pending reminders due on or before the current datetime.
        Marks reminder_sent=1 ONLY after confirmed SMTP delivery.
        Returns the count of reminders successfully sent in this cycle.
        """
        if not self._check_lock.acquire(blocking=False):
            return 0

        sent_count = 0
        cycle_time = datetime.now()
        try:
            due_tasks = self.db_manager.get_due_pending_tasks(cycle_time)
            for task in due_tasks:
                if self._stop_event.is_set():
                    break

                # Re-verify task state right before sending to avoid duplicates
                fresh_task = self.db_manager.get_task_by_id(int(task["id"]))
                if (
                    not fresh_task
                    or fresh_task["status"] != "Pending"
                    or int(fresh_task["reminder_sent"]) != 0
                ):
                    continue

                success, message = self.email_sender.send_reminder_email(fresh_task)
                if success:
                    self.db_manager.mark_reminder_sent(int(fresh_task["id"]))
                    sent_count += 1

                if self.on_reminder_processed is not None:
                    self.on_reminder_processed(fresh_task, success, message)

            if self.on_cycle_completed is not None:
                self.on_cycle_completed(cycle_time, sent_count)

        except DatabaseError as exc:
            self.logger.error("Scheduler database error: %s", exc)
        except Exception as exc:
            self.logger.exception("Unexpected error in reminder scheduler cycle: %s", exc)
        finally:
            self._check_lock.release()

        return sent_count

    def _run_loop(self) -> None:
        """Execute an initial check and then poll every `check_interval_seconds`."""
        # Brief 1-second delay allows GUI initialization to finish cleanly
        if self._stop_event.wait(1.0):
            return

        self.check_due_reminders()

        while not self._stop_event.wait(self.check_interval_seconds):
            self.check_due_reminders()
