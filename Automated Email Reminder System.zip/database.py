"""
database.py
-----------
Thread-safe SQLite persistence layer for the Automated Email Reminder
and Notification System. Automatically initializes the database and table
on startup and handles all CRUD operations using parameterized SQL queries.
"""

from __future__ import annotations

import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

from logger_config import setup_logger

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("REMINDER_DATA_DIR") or BASE_DIR)
DEFAULT_DB_PATH = DATA_DIR / "reminders.db"
DATETIME_FORMAT = "%Y-%m-%d %H:%M"


class DatabaseError(Exception):
    """Raised when a SQLite database operation fails."""


def parse_datetime_string(value: str) -> datetime:
    """
    Parse a date-time string supporting 'YYYY-MM-DD HH:MM' and
    'YYYY-MM-DD HH:MM:SS' formats.
    """
    cleaned = value.strip()
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            continue
    raise ValueError(
        "Invalid date/time format. Expected 'YYYY-MM-DD HH:MM' (e.g., 2026-11-25 14:30)."
    )


class DatabaseManager:
    """Manages SQLite database connections and task records safely across threads."""

    def __init__(self, db_path: str | Path = DEFAULT_DB_PATH) -> None:
        self.db_path = Path(db_path)
        self._lock = threading.Lock()
        self.logger = setup_logger()
        self.initialize_database()

    @contextmanager
    def _connect(self):
        """Yield a SQLite connection, committing or rolling back and always closing it."""
        conn = sqlite3.connect(self.db_path, timeout=15.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def initialize_database(self) -> None:
        """Create the tasks table and index if they do not already exist."""
        with self._lock:
            try:
                with self._connect() as conn:
                    conn.execute(
                        """
                        CREATE TABLE IF NOT EXISTS tasks (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            title TEXT NOT NULL,
                            description TEXT NOT NULL DEFAULT '',
                            deadline TEXT NOT NULL,
                            recipient_email TEXT NOT NULL,
                            reminder_time TEXT NOT NULL,
                            status TEXT NOT NULL DEFAULT 'Pending',
                            reminder_sent INTEGER NOT NULL DEFAULT 0,
                            created_at TEXT NOT NULL,
                            sent_at TEXT DEFAULT NULL
                        )
                        """
                    )
                    conn.execute(
                        """
                        CREATE INDEX IF NOT EXISTS idx_tasks_pending_reminder
                        ON tasks (status, reminder_sent)
                        """
                    )
                    conn.commit()
                self.logger.info("SQLite database initialized at %s", self.db_path)
            except sqlite3.Error as exc:
                self.logger.error("Failed to initialize SQLite database: %s", exc)
                raise DatabaseError(f"Database initialization failed: {exc}") from exc

    def add_task(
        self,
        title: str,
        description: str,
        deadline: str,
        recipient_email: str,
        reminder_time: str,
    ) -> int:
        """Insert a new task into the database and return its generated ID."""
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            try:
                with self._connect() as conn:
                    cursor = conn.execute(
                        """
                        INSERT INTO tasks (
                            title, description, deadline, recipient_email,
                            reminder_time, status, reminder_sent, created_at
                        )
                        VALUES (?, ?, ?, ?, ?, 'Pending', 0, ?)
                        """,
                        (
                            title.strip(),
                            description.strip(),
                            deadline.strip(),
                            recipient_email.strip(),
                            reminder_time.strip(),
                            created_at,
                        ),
                    )
                    conn.commit()
                    task_id = int(cursor.lastrowid)
                self.logger.info(
                    "Task created [ID=%d] title='%s' recipient='%s' reminder='%s' deadline='%s'",
                    task_id,
                    title.strip(),
                    recipient_email.strip(),
                    reminder_time.strip(),
                    deadline.strip(),
                )
                return task_id
            except sqlite3.Error as exc:
                self.logger.error("Error adding task '%s': %s", title, exc)
                raise DatabaseError(f"Could not save task: {exc}") from exc

    def get_all_tasks(self) -> list[dict[str, Any]]:
        """Return all tasks ordered with Pending tasks first, then nearest reminder."""
        with self._lock:
            try:
                with self._connect() as conn:
                    rows = conn.execute(
                        """
                        SELECT id, title, description, deadline, recipient_email,
                               reminder_time, status, reminder_sent, created_at, sent_at
                        FROM tasks
                        ORDER BY
                            CASE WHEN status = 'Pending' THEN 0 ELSE 1 END,
                            reminder_time ASC,
                            id DESC
                        """
                    ).fetchall()
                return [dict(row) for row in rows]
            except sqlite3.Error as exc:
                self.logger.error("Error fetching tasks: %s", exc)
                raise DatabaseError(f"Could not fetch tasks: {exc}") from exc

    def get_task_by_id(self, task_id: int) -> dict[str, Any] | None:
        """Fetch a single task record by its primary key ID."""
        with self._lock:
            try:
                with self._connect() as conn:
                    row = conn.execute(
                        """
                        SELECT id, title, description, deadline, recipient_email,
                               reminder_time, status, reminder_sent, created_at, sent_at
                        FROM tasks
                        WHERE id = ?
                        """,
                        (task_id,),
                    ).fetchone()
                return dict(row) if row else None
            except sqlite3.Error as exc:
                self.logger.error("Error fetching task [ID=%d]: %s", task_id, exc)
                raise DatabaseError(f"Could not fetch task {task_id}: {exc}") from exc

    def get_due_pending_tasks(self, reference_time: datetime | None = None) -> list[dict[str, Any]]:
        """
        Return all Pending tasks whose reminder_sent flag is 0 and whose
        reminder_time is less than or equal to `reference_time`.
        """
        now_dt = reference_time or datetime.now()
        with self._lock:
            try:
                with self._connect() as conn:
                    rows = conn.execute(
                        """
                        SELECT id, title, description, deadline, recipient_email,
                               reminder_time, status, reminder_sent, created_at, sent_at
                        FROM tasks
                        WHERE status = 'Pending' AND reminder_sent = 0
                        ORDER BY reminder_time ASC, id ASC
                        """
                    ).fetchall()
            except sqlite3.Error as exc:
                self.logger.error("Error querying due reminders: %s", exc)
                raise DatabaseError(f"Could not query due reminders: {exc}") from exc

        due_tasks: list[dict[str, Any]] = []
        for row in rows:
            task = dict(row)
            try:
                reminder_dt = parse_datetime_string(task["reminder_time"])
                if reminder_dt <= now_dt:
                    due_tasks.append(task)
            except ValueError:
                self.logger.warning(
                    "Task [ID=%d] has invalid reminder_time '%s'; skipping.",
                    task["id"],
                    task["reminder_time"],
                )
        return due_tasks

    def mark_task_completed(self, task_id: int) -> bool:
        """Mark the specified task as Completed."""
        with self._lock:
            try:
                with self._connect() as conn:
                    cursor = conn.execute(
                        """
                        UPDATE tasks
                        SET status = 'Completed'
                        WHERE id = ? AND status != 'Completed'
                        """,
                        (task_id,),
                    )
                    conn.commit()
                    updated = cursor.rowcount > 0
                if updated:
                    self.logger.info("Task marked completed [ID=%d]", task_id)
                return updated
            except sqlite3.Error as exc:
                self.logger.error("Error completing task [ID=%d]: %s", task_id, exc)
                raise DatabaseError(f"Could not complete task: {exc}") from exc

    def mark_reminder_sent(self, task_id: int) -> bool:
        """
        Set reminder_sent = 1 and record the sent timestamp.
        Should only be called after SMTP delivery succeeds.
        """
        sent_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            try:
                with self._connect() as conn:
                    cursor = conn.execute(
                        """
                        UPDATE tasks
                        SET reminder_sent = 1, sent_at = ?
                        WHERE id = ? AND reminder_sent = 0
                        """,
                        (sent_at, task_id),
                    )
                    conn.commit()
                    updated = cursor.rowcount > 0
                if updated:
                    self.logger.info(
                        "Database updated: reminder_sent=1 for Task [ID=%d] at %s",
                        task_id,
                        sent_at,
                    )
                return updated
            except sqlite3.Error as exc:
                self.logger.error(
                    "Error updating reminder_sent for task [ID=%d]: %s", task_id, exc
                )
                raise DatabaseError(f"Could not update reminder status: {exc}") from exc

    def delete_task(self, task_id: int) -> bool:
        """Delete a task record permanently from SQLite."""
        with self._lock:
            try:
                with self._connect() as conn:
                    row = conn.execute(
                        "SELECT title FROM tasks WHERE id = ?", (task_id,)
                    ).fetchone()
                    cursor = conn.execute(
                        "DELETE FROM tasks WHERE id = ?", (task_id,)
                    )
                    conn.commit()
                    deleted = cursor.rowcount > 0
                if deleted:
                    title = row["title"] if row else "Unknown"
                    self.logger.info("Task deleted [ID=%d] title='%s'", task_id, title)
                return deleted
            except sqlite3.Error as exc:
                self.logger.error("Error deleting task [ID=%d]: %s", task_id, exc)
                raise DatabaseError(f"Could not delete task: {exc}") from exc

    def get_summary_counts(self) -> dict[str, int]:
        """Return aggregate dashboard counts for total, pending, completed, and sent."""
        with self._lock:
            try:
                with self._connect() as conn:
                    row = conn.execute(
                        """
                        SELECT
                            COUNT(*) AS total,
                            COALESCE(SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END), 0) AS pending,
                            COALESCE(SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END), 0) AS completed,
                            COALESCE(SUM(CASE WHEN reminder_sent = 1 THEN 1 ELSE 0 END), 0) AS sent
                        FROM tasks
                        """
                    ).fetchone()
                return {
                    "total": int(row["total"]),
                    "pending": int(row["pending"]),
                    "completed": int(row["completed"]),
                    "sent": int(row["sent"]),
                }
            except sqlite3.Error as exc:
                self.logger.error("Error reading summary counts: %s", exc)
                return {"total": 0, "pending": 0, "completed": 0, "sent": 0}
